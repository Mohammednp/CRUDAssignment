package crud;
import java.sql.*;

public class Read {

	public static void main(String[] args) throws SQLException {
		Connection con=null;
		Statement stmnt=null;
		ResultSet result=null;
		try {
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/student", "root", "test");
			if(con!=null) {
			stmnt = con.createStatement();
			}
			if(stmnt!=null) { //int == d, String == s
				result = stmnt.executeQuery("select sid,sname,sage,saddr from student");
			}
			if(result!=null) {
				System.out.println("SID\tSNAME\tSAGE\tSADDR");
				while(result.next()) {
					int sid=result.getInt("sid");
					String sname=result.getString("sname");
					int sage=result.getInt("sage");
					String saddr=result.getString("saddr");
					System.out.println(sid+"\t"+sname+"\t"+sage+"\t"+saddr);
				}
			}
		}catch(SQLException e) {
			System.out.println(e.getLocalizedMessage());
		}catch(Exception e1) {
			System.out.println(e1.getLocalizedMessage());
		}finally {
			if(con!=null) {
				con.close();
			}if(stmnt!=null) {
				stmnt.close();
			}if(result!=null) {
				result.close();
			}
		}
}

}
