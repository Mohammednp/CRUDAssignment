package crud;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class Delete {

	public static void main(String[] args) {
		Connection con=null;
		Statement stmnt=null;
		
		Scanner scan=new Scanner(System.in);
		System.out.print("Enter the Sid:: ");
		int sid=scan.nextInt();

		try {
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/student", "root", "test");
			if(con!=null) {
			stmnt = con.createStatement();
			}
			if(stmnt!=null) { //int == d, String == s
				int insert = stmnt.executeUpdate("delete into student (sid,sname,sage,saddr) where sid='"+sid+"'");
				System.out.println(insert);
			}
		}catch(SQLException e) {
			System.out.println(e.getLocalizedMessage());
		}catch(Exception e1) {
			System.out.println(e1.getLocalizedMessage());
		}finally {
			try {
			if(con!=null) {
				con.close();
			}if(stmnt!=null) {
				stmnt.close();
			}
		}catch(Exception e) {
			System.out.println(e);
		}
}
	}


	
}
