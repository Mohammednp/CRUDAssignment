package crud;

import java.sql.*;
import java.util.Scanner;
public class InsertStudent {

	
	public static void main(String[] args) {
		
			Connection con=null;
			Statement stmnt=null;
			
			Scanner scan=new Scanner(System.in);
			System.out.print("Enter the Sid:: ");
			String sid=scan.next();
			System.out.print("Enter the Sname:: ");
			String sname=scan.next();
			System.out.print("Enter the Sage:: ");
			String sage=scan.next();
			System.out.print("Enter the Saddr:: ");
			String saddr=scan.next();
			
			
			try {
				con = DriverManager.getConnection("jdbc:mysql://localhost:3306/student", "root", "test");
				if(con!=null) {
				stmnt = con.createStatement();
				}
				if(stmnt!=null) { //int == d, String == s
					int insert = stmnt.executeUpdate("insert into student (sid,sname,sage,saddr) values ('"+sid+"','"+sname+"','"+sage+"','"+saddr+"')");
					System.out.println(insert);
				}
			}catch(SQLException e) {
				System.out.println(e.getLocalizedMessage());
			}catch(Exception e1) {
				System.out.println(e1.getLocalizedMessage());
			}finally {
				try {
				if(con!=null) {
					con.close();
				}if(stmnt!=null) {
					stmnt.close();
				}
			}catch(Exception e) {
				System.out.println(e);
			}
	}
	}
}
